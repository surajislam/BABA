# ChatBot/modules/handlers.py (or another appropriate handler module file)

import asyncio
import random
from pyrogram import filters, Client # Import Client for type hinting
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery
from pyrogram.enums import ChatAction, ChatMembersFilter

# --- IMPORTANT IMPORTS FROM YOUR PROJECT'S CORE ---
# Assuming 'app' is the Pyrogram client instance defined in your main bot package (e.g., BrandrdXMusic)
# and then re-exported via ChatBot/__init__.py or passed globally.
from ChatBot import app

# Assuming your database functions and chatbot_api instance are defined in ChatBot/database.py
from ChatBot.database import is_chatbot_enabled, enable_chatbot, disable_chatbot, chatbot_api, add_chat, chatsdb

# Assuming your configuration variables are defined in config.py
from config import IMG, START, BOT_USERNAME, SUPPORT_GROUP, LOGGER_GROUP_ID


# ✅ Text filter for chatbot
async def text_filter(_, __, m: Message):
    """Filters valid chatbot messages."""
    return (
        bool(m.text)
        and len(m.text) <= 69
        and not m.text.startswith(("!", "/"))
        and (not m.reply_to_message or m.reply_to_message.reply_to_message_id == m._client.me.id)
    )

chatbot_filter = filters.create(text_filter)


# ✅ Chatbot handler (DM me always + Group me toggle)
@app.on_message(
    ((filters.text & chatbot_filter) | filters.mentioned)
    & ~filters.bot
    & ~filters.sticker
)
async def chatbot(_, message: Message):
    """Replies in DM always and in groups based on toggle."""
    chat_id = message.chat.id

    if message.chat.type == "private" or await is_chatbot_enabled(chat_id) or message.mentioned:
        await app.send_chat_action(chat_id, ChatAction.TYPING)
        # Corrected method call here
        reply = chatbot_api.generate_chatbot_response(message.text)
        await message.reply_text(reply or "❖ ChatBot Error. Contact @II_SB_SIMPLE_II.")


# ✅ Enable/Disable button (Group ke liye)
@app.on_message(filters.command(["chatbot"]) & filters.group & ~filters.bot)
async def chatbot_toggle(_, message: Message):
    """Shows chatbot enable/disable options in groups."""

    # ✅ Admin list fetch karo
    admins = []
    async for member in app.get_chat_members(message.chat.id, filter=ChatMembersFilter.ADMINISTRATORS):
        admins.append(member.user.id)

    if message.from_user.id not in admins:
        await message.reply_text("❖ You are not an admin.")
        return

    # ✅ Button with toggle options
    is_enabled = await is_chatbot_enabled(message.chat.id)
    btn_text = "🚫 Disable" if is_enabled else "✅ Enable"
    btn_callback = f"rmchat_{message.chat.id}" if is_enabled else f"addchat_{message.chat.id}"

    await message.reply_text(
        f"❖ Chatbot is currently {'enabled' if is_enabled else 'disabled'}.",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton(btn_text, callback_data=btn_callback)]
        ]),
    )


# ✅ Callback handler with toggle system
@app.on_callback_query(filters.regex(r"^(addchat|rmchat)_"))
async def chatbot_callback(_, query: CallbackQuery):
    """Handles enabling/disabling chatbot in groups."""

    chat_id = int(query.data.split("_")[1])
    user_id = query.from_user.id

    try:
        # ✅ Admin check
        admins = []
        async for member in app.get_chat_members(chat_id, filter=ChatMembersFilter.ADMINISTRATORS):
            admins.append(member.user.id)

        if user_id not in admins:
            await query.answer("❖ You are not an admin.", show_alert=True)
            return

        # ✅ Toggle system with button intact
        if "addchat" in query.data:
            if await is_chatbot_enabled(chat_id):
                await query.message.edit_text(
                    f"✅ Chatbot is already enabled by {query.from_user.mention}.",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("🚫 Disable", callback_data=f"rmchat_{chat_id}")]
                    ])
                )
            else:
                await enable_chatbot(chat_id)
                await query.message.edit_text(
                    f"✅ Chatbot enabled by {query.from_user.mention}.",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("🚫 Disable", callback_data=f"rmchat_{chat_id}")]
                    ])
                )

        elif "rmchat" in query.data:
            if not await is_chatbot_enabled(chat_id):
                await query.message.edit_text(
                    f"🚫 Chatbot is already disabled by {query.from_user.mention}.",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("✅ Enable", callback_data=f"addchat_{chat_id}")]
                    ])
                )
            else:
                await disable_chatbot(chat_id)
                await query.message.edit_text(
                    f"🚫 Chatbot disabled by {query.from_user.mention}.",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("✅ Enable", callback_data=f"addchat_{chat_id}")]
                    ])
                )

        # ✅ Callback confirm karo button ko refresh karne ke liye
        await query.answer()

    except Exception as e:
        await query.message.edit_text(f"❖ Error: {str(e)}")
        await query.answer()

# --- New Bot Added to Group Handler ---
@app.on_message(filters.new_chat_members)
async def on_new_chat_members(client: Client, message: Message):
    if (await client.get_me()).id in [user.id for user in message.new_chat_members]:
        chat_id = message.chat.id
        chat_title = message.chat.title
        added_by = message.from_user.mention if message.from_user else "Unknown User"
        chatusername = f"@{message.chat.username}" if message.chat.username else "Private Chat"

        try:
            invite_link = await client.export_chat_invite_link(chat_id)
        except Exception:
            invite_link = "Not Available"

        await add_chat(chat_id, chat_title)

        await message.reply_photo(
            photo=random.choice(IMG),
            caption=START,
            parse_mode="HTML", # Added parse_mode
            reply_markup=InlineKeyboardMarkup([
                [
                    InlineKeyboardButton("ᴧᴅᴅ ϻє ʙᴧʙʏ", url=f"https://t.me/{BOT_USERNAME}?startgroup=s&admin=delete_messages+manage_video_chats+pin_messages+invite_users"),
                    InlineKeyboardButton("ᴊσɪη sᴜᴘᴘσʀᴛ", url=f"https://t.me/{SUPPORT_GROUP}")
                ]
            ])
        )

        log_msg = (
            f"<b>✦ ʙᴏᴛ #ᴀᴅᴅᴇᴅ ɪɴ ᴀ ɢʀᴏᴜᴘ</b>\n\n"
            f"**⚘ ɢʀᴏᴜᴘ ɴᴀᴍᴇ :** {chat_title}\n"
            f"**⚘ ɢʀᴏᴜᴘ ɪᴅ :** {chat_id}\n"
            f"**⚘ ᴜsᴇʀɴᴀᴍᴇ :** {chatusername}\n"
            f"**⚘ ɢʀᴏᴜᴘ ʟɪɴᴋ : [ᴛᴀᴘ ʜᴇʀᴇ]({invite_link})**\n"
            f"**⚘ ᴀᴅᴅᴇᴅ ʙʏ :** {added_by}"
        )

        await app.send_photo(
            LOGGER_GROUP_ID,
            photo=random.choice(IMG),
            caption=log_msg,
            parse_mode="HTML", # Added parse_mode
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("ɢʀᴏᴜᴘ ʟɪɴᴋ", url=invite_link if invite_link != "Not Available" else f"https://t.me/{SUPPORT_GROUP}")]
            ])
        )


# --- New Bot Left Group Handler ---
@app.on_message(filters.left_chat_member)
async def on_left_chat_member(client: Client, message: Message):
    if (await client.get_me()).id == message.left_chat_member.id:
        chat_id = message.chat.id
        chat_title = message.chat.title
        remove_by = message.from_user.mention if message.from_user else "Unknown User"

        await chatsdb.delete_one({"chat_id": chat_id}) # Assuming chatsdb is a direct object or accessible

        left_msg = (
            f"<b>✦ ʙᴏᴛ #ʟᴇғᴛ ᴀ ɢʀᴏᴜᴘ</b>\n\n"
            f"**⚘ ɢʀᴏᴜᴘ ɴᴀᴍᴇ :** {chat_title}\n"
            f"**⚘ ɢʀᴏᴜᴘ ɪᴅ :** {chat_id}\n"
            f"**⚘ ʀᴇᴍᴏᴠᴇᴅ ʙʏ :** {remove_by}"
        )

        await app.send_photo(
            LOGGER_GROUP_ID,
            photo=random.choice(IMG),
            caption=left_msg,
            parse_mode="HTML", # Added parse_mode
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("sᴇᴇ ɢʀᴏᴜᴘ", url=f"https://t.me/{message.chat.username}" if message.chat.username else f"https://t.me/{SUPPORT_GROUP}")]
            ])
        )