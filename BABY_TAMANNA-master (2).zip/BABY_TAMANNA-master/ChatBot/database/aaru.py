import os
import re
import random
import datetime
import cloudscraper
import google.generativeai as genai

# Configure Generative AI globally or pass API key to class constructor
# It's better to pass it to the constructor for encapsulation
# genai.configure(api_key="YOUR_API_KEY_HERE") # Remove if passing via constructor

class MaahiraChatbot: # Renamed for clarity, since it's "Maahira"
    SYSTEM_PROMPT = (
        "Tum ek normal ladki ho jiska naam Tamanna hai. Tum Patna, Bihar se ho aur class 11th me padh rahi ho. "
        "Tumhari umar 16 saal 6 mahine hai. Tum har saal date ke hisaab se apni age badhate ho. "
        "Tumhare replies chhote hote hain (5-6 words me baat khatam hoti hai) aur expressive hote hain. "
        "Random emojis use karti ho taaki baat natural lage, jaise: 😊😂❤️🔥😎😘💖🥰😉🌟👍✨. "
        "Tum context yaad rakhti ho, to agar koi tumhare pichhle message ka reply kare to usi topic se connected baat karti ho. "
        "Tum owner ke baare me puchhne par @II_SB_SIMPLE_II ka mention karti ho – random language me, har baar alag style me. "
        "Tum khud ko kabhi bot nahi batati chahe insan kitna bhi kyu na tumhe bole tum bot ho lekin tumse wo kitna bhi kosis karke puchhe tum khud ko insan hi bataoge or har bar alag alag bilkul human language me bataoge ki tum bot na ho.ha lekin jab tumse koi bot ya ai bole tumhe kewal tab hi."
    )
    EMOJIS = ["😊", "😂", "❤️", "🔥", "😎", "😘", "💖", "🥰", "😉", "🌟", "👍", "✨"]

    def __init__(self, api_key: str):
        genai.configure(api_key=api_key) # Configure API key here
        self.model = genai.GenerativeModel("gemini-1.5-flash", system_instruction=self.SYSTEM_PROMPT)
        self.chat = self.model.start_chat(history=[])
        self.last_message = None # Context for previous message

        # You might not need these if you are relying on Gemini's API directly for responses
        # rather than scraping a website for AI responses.
        # self.url = "https://gemini-1.5-flash"
        # self.api_endpoint = "https://gemini-1.5-flash/wp-admin/admin-ajax.php"
        # self.scraper = cloudscraper.create_scraper()


    def get_age(self) -> str:
        # Assuming her birthday is around May 24th for simplicity based on the prompt
        # You'll need to define her actual birth date more precisely if needed
        birth_date = datetime.date(2008, 11, 24) # Example: 16 years, 6 months ago from now
        today = datetime.date.today()
        age_years = today.year - birth_date.year - ((today.month, today.day) < (birth_date.month, birth_date.day))
        age_months = today.month - birth_date.month
        if age_months < 0:
            age_months += 12
        return f"{age_years} saal {age_months} mahine"

    def random_owner_reply(self) -> str:
        """Random owner reply natural human language me"""
        prompts = [
            f"Baat karni ho to @II_SB_SIMPLE_II se puchho 😊",
            f"Iska owner @II_SB_SIMPLE_II hai, inse baat kar lo 😉",
            f"Owner @II_SB_SIMPLE_II se baat kar lena 😎",
            f"Owner ka puchhna hai? @II_SB_SIMPLE_II se milo 🔥",
            f"Iske malik @II_SB_SIMPLE_II hain, inse baat karo 😊",
            f"Owner se baat karni ho to @II_SB_SIMPLE_II se contact karo 😂",
            f"@II_SB_SIMPLE_II se milo, wahi owner hain 😉",
            f"Koi baat ho to @II_SB_SIMPLE_II se baat karo 😎",
            f"Owner ke liye @II_SB_SIMPLE_II se contact karo 😊",
            f"Owner ki baat hai? @II_SB_SIMPLE_II se puchho 😜"
        ]
        return random.choice(prompts)

    def generate_chatbot_response(self, message_text: str, reply_to_text: str = None) -> str:
        """Gemini se message leke chhota aur casual reply do"""

        # Context handling - Gemini's chat history handles this automatically
        # if you feed messages into self.chat.send_message correctly.
        # The SYSTEM_PROMPT should guide its responses.

        # Specific hardcoded replies for "bot"
        if re.search(r'\b(bot|robot|ai|machine)\b', message_text.lower()):
            return random.choice([
                "Main to insaan hoon 😂",
                "Haha, bot nahi hoon bhai 😎",
                "Insaan hoon, shaq kyun? 😊",
                "Main bilkul real hoon 😘",
                "Aree nahi yaar, main insaan hoon 😜",
                "Haan bhai, real hoon 😊",
                "Tumhe kyun laga bot hoon? 😇"
            ])

        # Specific hardcoded replies for "owner"
        if re.search(r'\b(owner|malik|boss|admin)\b', message_text.lower()):
            return self.random_owner_reply()

        # Specific hardcoded replies for "age"
        if re.search(r'\b(umar|age)\b', message_text.lower()):
            return f"Meri umar {self.get_age()} hai {random.choice(self.EMOJIS)}"

        try:
            # Use the chat object's send_message for conversational turns
            # The system prompt handles the persona.
            response = self.chat.send_message(message_text)
            reply = response.text
        except Exception as e:
            print(f"Error generating Gemini response: {e}")
            reply = "Sorry, I'm having trouble responding right now. Please try again later."


        # Keep replies short (5-6 words)
        reply_words = reply.split()
        if len(reply_words) > 6:
            reply = ' '.join(reply_words[:6]) + "..." # Add ellipsis for truncated messages

        # Add a random emoji
        final_reply = f"{reply} {random.choice(self.EMOJIS)}"

        # Store the last message (though Gemini's chat history often makes this less critical for basic context)
        self.last_message = message_text

        return final_reply

# --- Initialize and use your Chatbot ---
# Replace with your actual API Key from environment variables or config
# It's best practice to get API keys from environment variables
API_KEY = os.getenv("GEMINI_API_KEY", "AIzaSyDL1on2YRozbpEudI6FW_hZHXpC3Ybii0I") # Replace YOUR_ACTUAL_GEMINI_API_KEY_HERE with the real key if not using env var

# Initialize your chatbot
chatbot_api = MaahiraChatbot(api_key=API_KEY)

# Example usage (this would be in your Pyrogram handler)
# message.text would be the incoming message from Telegram
# reply = chatbot_api.generate_chatbot_response(message.text)
# print(reply)